// Ana JavaScript dosyası
document.addEventListener('DOMContentLoaded', function() {
    // User stats güncelleme
    updateUserStats();
    
    // Market auto-refresh
    if (window.location.pathname === '/marketplace') {
        setInterval(updateUserStats, 30000); // 30 saniyede bir güncelle
    }
    
    // Form validasyonları
    setupFormValidations();
    
    // Confirmation dialogs
    setupConfirmationDialogs();
    
    // Real-time form updates
    setupRealTimeUpdates();
});

/**
 * Kullanıcı istatistiklerini güncelle
 */
function updateUserStats() {
    fetch('/api/user_stats')
        .then(response => {
            if (response.ok) {
                return response.json();
            }
            throw new Error('Failed to fetch user stats');
        })
        .then(data => {
            // Para güncelle
            const moneyElements = document.querySelectorAll('.user-money');
            moneyElements.forEach(element => {
                element.textContent = formatMoney(data.money);
            });
            
            // Envanter sayısı güncelle
            const inventoryElements = document.querySelectorAll('.inventory-count');
            inventoryElements.forEach(element => {
                element.textContent = data.inventory_items;
            });
            
            // Aktif ilan sayısı güncelle
            const listingElements = document.querySelectorAll('.listing-count');
            listingElements.forEach(element => {
                element.textContent = data.active_listings;
            });
        })
        .catch(error => {
            console.log('Stats update failed:', error);
        });
}

/**
 * Parayı formatla
 */
function formatMoney(amount) {
    return new Intl.NumberFormat('tr-TR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount) + ' ₺';
}

/**
 * Form validasyonlarını ayarla
 */
function setupFormValidations() {
    // Satış formu validasyonu
    const sellForm = document.getElementById('sell-form');
    if (sellForm) {
        sellForm.addEventListener('submit', function(e) {
            const price = parseFloat(document.getElementById('price').value);
            const quantity = parseInt(document.getElementById('quantity').value);
            const maxQuantity = parseInt(document.getElementById('max-quantity').value);
            
            if (price <= 0) {
                e.preventDefault();
                showAlert('Fiyat 0\'dan büyük olmalıdır!', 'error');
                return;
            }
            
            if (quantity <= 0 || quantity > maxQuantity) {
                e.preventDefault();
                showAlert(`Miktar 1 ile ${maxQuantity} arasında olmalıdır!`, 'error');
                return;
            }
        });
    }
    
    // Kayıt formu validasyonu
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const username = document.getElementById('username').value;
            
            if (username.length < 3) {
                e.preventDefault();
                showAlert('Kullanıcı adı en az 3 karakter olmalıdır!', 'error');
                return;
            }
            
            if (password.length < 6) {
                e.preventDefault();
                showAlert('Şifre en az 6 karakter olmalıdır!', 'error');
                return;
            }
        });
    }
}

/**
 * Onay dialoglarını ayarla
 */
function setupConfirmationDialogs() {
    // Satın alma onayı
    const buyButtons = document.querySelectorAll('.buy-button');
    buyButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const itemName = this.dataset.itemName;
            const price = this.dataset.price;
            const quantity = this.dataset.quantity;
            const totalCost = (parseFloat(price) * parseInt(quantity)).toFixed(2);
            
            if (!confirm(`${quantity} adet ${itemName} ürününü ${totalCost} ₺'ye satın almak istediğinizden emin misiniz?`)) {
                e.preventDefault();
            }
        });
    });
    
    // İlan iptal etme onayı
    const cancelButtons = document.querySelectorAll('.cancel-listing-button');
    cancelButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Bu ilanı iptal etmek istediğinizden emin misiniz? Ürün envanterinize geri dönecektir.')) {
                e.preventDefault();
            }
        });
    });
    
    // Çıkış onayı
    const logoutButton = document.getElementById('logout-button');
    if (logoutButton) {
        logoutButton.addEventListener('click', function(e) {
            if (!confirm('Çıkış yapmak istediğinizden emin misiniz?')) {
                e.preventDefault();
            }
        });
    }
}

/**
 * Real-time form güncellemelerini ayarla
 */
function setupRealTimeUpdates() {
    // Satış formunda toplam hesaplama
    const priceInput = document.getElementById('price');
    const quantityInput = document.getElementById('quantity');
    const totalDisplay = document.getElementById('total-amount');
    
    if (priceInput && quantityInput && totalDisplay) {
        function updateTotal() {
            const price = parseFloat(priceInput.value) || 0;
            const quantity = parseInt(quantityInput.value) || 0;
            const total = (price * quantity).toFixed(2);
            totalDisplay.textContent = `Toplam: ${total} ₺`;
        }
        
        priceInput.addEventListener('input', updateTotal);
        quantityInput.addEventListener('input', updateTotal);
        
        // İlk yükleme
        updateTotal();
    }
    
    // Miktar slider ile input senkronizasyonu
    const quantitySlider = document.getElementById('quantity-slider');
    const quantityInputField = document.getElementById('quantity');
    
    if (quantitySlider && quantityInputField) {
        quantitySlider.addEventListener('input', function() {
            quantityInputField.value = this.value;
            // Toplam hesaplamayı tetikle
            quantityInputField.dispatchEvent(new Event('input'));
        });
        
        quantityInputField.addEventListener('input', function() {
            quantitySlider.value = this.value;
        });
    }
}

/**
 * Alert göster
 */
function showAlert(message, type = 'info') {
    const alertContainer = document.getElementById('alert-container');
    if (!alertContainer) {
        // Alert container yoksa oluştur
        const container = document.createElement('div');
        container.id = 'alert-container';
        container.style.position = 'fixed';
        container.style.top = '20px';
        container.style.right = '20px';
        container.style.zIndex = '1000';
        document.body.appendChild(container);
    }
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.style.marginBottom = '10px';
    alert.style.padding = '12px 20px';
    alert.style.borderRadius = '8px';
    alert.style.maxWidth = '300px';
    alert.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
    alert.innerHTML = `
        ${message}
        <button onclick="this.parentElement.remove()" style="float: right; background: none; border: none; font-size: 18px; cursor: pointer;">&times;</button>
    `;
    
    document.getElementById('alert-container').appendChild(alert);
    
    // 5 saniye sonra otomatik kaldır
    setTimeout(() => {
        if (alert.parentElement) {
            alert.remove();
        }
    }, 5000);
}

/**
 * Loading spinner göster/gizle
 */
function toggleLoading(element, show = true) {
    if (show) {
        element.innerHTML = '<span class="loading"></span> Yükleniyor...';
        element.disabled = true;
    } else {
        element.innerHTML = element.dataset.originalText || 'Tamam';
        element.disabled = false;
    }
}

/**
 * Fiyat formatı güncelle
 */
function formatPriceInput(input) {
    let value = parseFloat(input.value);
    if (!isNaN(value)) {
        input.value = value.toFixed(2);
    }
}

/**
 * Sayfa yenilemesi olmadan form gönderimi
 */
function submitFormAjax(formId, successCallback) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(form);
        const button = form.querySelector('button[type="submit"]');
        
        if (button) {
            button.dataset.originalText = button.innerHTML;
            toggleLoading(button, true);
        }
        
        fetch(form.action, {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (response.ok) {
                return response.json().catch(() => ({ success: true }));
            }
            throw new Error('Network response was not ok');
        })
        .then(data => {
            if (successCallback) {
                successCallback(data);
            }
            showAlert('İşlem başarıyla tamamlandı!', 'success');
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('İşlem sırasında hata oluştu!', 'error');
        })
        .finally(() => {
            if (button) {
                toggleLoading(button, false);
            }
        });
    });
}

/**
 * Arama işlevselliği
 */
function setupSearch() {
    const searchInput = document.getElementById('search-input');
    if (!searchInput) return;
    
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const items = document.querySelectorAll('.market-item, .inventory-item');
        
        items.forEach(item => {
            const itemName = item.querySelector('.market-item-title, .inventory-item-name');
            if (itemName) {
                const text = itemName.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            }
        });
    });
}

/**
 * Sıralama işlevselliği
 */
function setupSorting() {
    const sortSelect = document.getElementById('sort-select');
    if (!sortSelect) return;
    
    sortSelect.addEventListener('change', function() {
        const sortBy = this.value;
        const container = document.querySelector('.market-items, .inventory-grid');
        if (!container) return;
        
        const items = Array.from(container.children);
        
        items.sort((a, b) => {
            switch (sortBy) {
                case 'price-low':
                    return getItemPrice(a) - getItemPrice(b);
                case 'price-high':
                    return getItemPrice(b) - getItemPrice(a);
                case 'name':
                    return getItemName(a).localeCompare(getItemName(b));
                case 'date':
                default:
                    return 0; // Varsayılan sıralama
            }
        });
        
        // Sıralanmış öğeleri tekrar ekle
        items.forEach(item => container.appendChild(item));
    });
}

/**
 * Yardımcı fonksiyonlar
 */
function getItemPrice(element) {
    const priceElement = element.querySelector('.market-item-price');
    if (priceElement) {
        return parseFloat(priceElement.textContent.replace(/[^\d.,]/g, '').replace(',', '.')) || 0;
    }
    return 0;
}

function getItemName(element) {
    const nameElement = element.querySelector('.market-item-title, .inventory-item-name');
    return nameElement ? nameElement.textContent : '';
}

/**
 * Keyboard shortcuts
 */
document.addEventListener('keydown', function(e) {
    // Ctrl+M: Marketplace'e git
    if (e.ctrlKey && e.key === 'm') {
        e.preventDefault();
        window.location.href = '/marketplace';
    }
    
    // Ctrl+I: Inventory'ye git
    if (e.ctrlKey && e.key === 'i') {
        e.preventDefault();
        window.location.href = '/inventory';
    }
    
    // Ctrl+P: Profile'a git
    if (e.ctrlKey && e.key === 'p') {
        e.preventDefault();
        window.location.href = '/profile';
    }
});

// Sayfa yüklendikten sonra çalışacak ek işlemler
window.addEventListener('load', function() {
    setupSearch();
    setupSorting();
    
    // Performance optimizasyonu için lazy loading
    if ('IntersectionObserver' in window) {
        const images = document.querySelectorAll('img[data-src]');
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        images.forEach(img => imageObserver.observe(img));
    }
});
