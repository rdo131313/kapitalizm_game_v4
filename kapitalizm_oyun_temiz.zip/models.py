from datetime import datetime
from database import get_db_connection

class User:
    def __init__(self, id=None, username=None, email=None, money=1000.0):
        self.id = id
        self.username = username
        self.email = email
        self.money = money
    
    @classmethod
    def get_by_id(cls, user_id):
        """ID ile kullanıcı getir"""
        conn = get_db_connection()
        user_data = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
        conn.close()
        
        if user_data:
            return cls(
                id=user_data['id'],
                username=user_data['username'],
                email=user_data['email'],
                money=user_data['money']
            )
        return None
    
    @classmethod
    def get_by_username(cls, username):
        """Kullanıcı adı ile kullanıcı getir"""
        conn = get_db_connection()
        user_data = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        
        if user_data:
            return cls(
                id=user_data['id'],
                username=user_data['username'],
                email=user_data['email'],
                money=user_data['money']
            )
        return None
    
    def update_money(self, amount):
        """Para güncelle"""
        conn = get_db_connection()
        conn.execute('UPDATE users SET money = ? WHERE id = ?', (amount, self.id))
        conn.commit()
        conn.close()
        self.money = amount

class Item:
    def __init__(self, id=None, name=None, description=None, base_price=10.0):
        self.id = id
        self.name = name
        self.description = description
        self.base_price = base_price
    
    @classmethod
    def get_by_id(cls, item_id):
        """ID ile ürün getir"""
        conn = get_db_connection()
        item_data = conn.execute('SELECT * FROM items WHERE id = ?', (item_id,)).fetchone()
        conn.close()
        
        if item_data:
            return cls(
                id=item_data['id'],
                name=item_data['name'],
                description=item_data['description'],
                base_price=item_data['base_price']
            )
        return None
    
    @classmethod
    def get_all(cls):
        """Tüm ürünleri getir"""
        conn = get_db_connection()
        items_data = conn.execute('SELECT * FROM items ORDER BY name').fetchall()
        conn.close()
        
        items = []
        for item_data in items_data:
            items.append(cls(
                id=item_data['id'],
                name=item_data['name'],
                description=item_data['description'],
                base_price=item_data['base_price']
            ))
        return items

class Inventory:
    def __init__(self, id=None, user_id=None, item_id=None, quantity=0):
        self.id = id
        self.user_id = user_id
        self.item_id = item_id
        self.quantity = quantity
    
    @classmethod
    def get_user_inventory(cls, user_id):
        """Kullanıcının envanterini getir"""
        conn = get_db_connection()
        inventory_data = conn.execute('''
            SELECT inv.*, i.name, i.description, i.base_price
            FROM inventory inv
            JOIN items i ON inv.item_id = i.id
            WHERE inv.user_id = ? AND inv.quantity > 0
            ORDER BY i.name
        ''', (user_id,)).fetchall()
        conn.close()
        
        inventory = []
        for item_data in inventory_data:
            inventory.append({
                'id': item_data['id'],
                'item_id': item_data['item_id'],
                'name': item_data['name'],
                'description': item_data['description'],
                'base_price': item_data['base_price'],
                'quantity': item_data['quantity']
            })
        return inventory
    
    @classmethod
    def add_item(cls, user_id, item_id, quantity):
        """Enventere ürün ekle"""
        conn = get_db_connection()
        
        # Mevcut envanter kontrolü
        existing = conn.execute(
            'SELECT id, quantity FROM inventory WHERE user_id = ? AND item_id = ?',
            (user_id, item_id)
        ).fetchone()
        
        if existing:
            # Mevcut miktarı güncelle
            new_quantity = existing['quantity'] + quantity
            conn.execute(
                'UPDATE inventory SET quantity = ? WHERE id = ?',
                (new_quantity, existing['id'])
            )
        else:
            # Yeni kayıt oluştur
            conn.execute(
                'INSERT INTO inventory (user_id, item_id, quantity) VALUES (?, ?, ?)',
                (user_id, item_id, quantity)
            )
        
        conn.commit()
        conn.close()
    
    @classmethod
    def remove_item(cls, user_id, item_id, quantity):
        """Envanterden ürün çıkar"""
        conn = get_db_connection()
        
        existing = conn.execute(
            'SELECT id, quantity FROM inventory WHERE user_id = ? AND item_id = ?',
            (user_id, item_id)
        ).fetchone()
        
        if existing and existing['quantity'] >= quantity:
            new_quantity = existing['quantity'] - quantity
            
            if new_quantity == 0:
                conn.execute('DELETE FROM inventory WHERE id = ?', (existing['id'],))
            else:
                conn.execute(
                    'UPDATE inventory SET quantity = ? WHERE id = ?',
                    (new_quantity, existing['id'])
                )
            
            conn.commit()
            conn.close()
            return True
        
        conn.close()
        return False

class MarketListing:
    def __init__(self, id=None, seller_id=None, item_id=None, quantity=0, price=0.0, is_active=True):
        self.id = id
        self.seller_id = seller_id
        self.item_id = item_id
        self.quantity = quantity
        self.price = price
        self.is_active = is_active
    
    @classmethod
    def get_active_listings(cls, exclude_user_id=None):
        """Aktif ilanları getir"""
        conn = get_db_connection()
        
        query = '''
            SELECT ml.*, i.name as item_name, i.description as item_description,
                   u.username as seller_username
            FROM market_listings ml
            JOIN items i ON ml.item_id = i.id
            JOIN users u ON ml.seller_id = u.id
            WHERE ml.is_active = 1
        '''
        params = []
        
        if exclude_user_id:
            query += ' AND ml.seller_id != ?'
            params.append(exclude_user_id)
        
        query += ' ORDER BY ml.created_at DESC'
        
        listings_data = conn.execute(query, params).fetchall()
        conn.close()
        
        listings = []
        for listing_data in listings_data:
            listings.append({
                'id': listing_data['id'],
                'seller_id': listing_data['seller_id'],
                'item_id': listing_data['item_id'],
                'quantity': listing_data['quantity'],
                'price': listing_data['price'],
                'item_name': listing_data['item_name'],
                'item_description': listing_data['item_description'],
                'seller_username': listing_data['seller_username'],
                'created_at': listing_data['created_at']
            })
        return listings
    
    @classmethod
    def create_listing(cls, seller_id, item_id, quantity, price):
        """Yeni ilan oluştur"""
        conn = get_db_connection()
        
        conn.execute('''
            INSERT INTO market_listings (seller_id, item_id, quantity, price, created_at, is_active)
            VALUES (?, ?, ?, ?, ?, 1)
        ''', (seller_id, item_id, quantity, price, datetime.now()))
        
        listing_id = conn.lastrowid
        conn.commit()
        conn.close()
        
        return listing_id
    
    @classmethod
    def deactivate_listing(cls, listing_id):
        """İlanı pasif yap"""
        conn = get_db_connection()
        conn.execute('UPDATE market_listings SET is_active = 0 WHERE id = ?', (listing_id,))
        conn.commit()
        conn.close()
