# Kapitalizm Ticaret Oyunu

Flask tabanlı web ticaret oyunu. Kullanıcılar kayıt olup giriş yaparak ticaret yapabilir, iş kolları satın alabilir ve pasif gelir elde edebilirler.

## Özellikler

- **Kullanıcı Sistemi**: Kayıt olma, giriş yapma, profil yönetimi
- **Envanter Yönetimi**: Ürün saklama ve yönetme
- **Pazar Sistemi**: Diğer oyuncularla ticaret yapma
- **İş Kolları**: 46 farklı iş kolu (dükkânlar, madenler, araziler, fabrikalar, hizmet sektörü)
- **Seviye Sistemi**: İlerledikçe yeni iş kollarının kilidi açılır
- **Gerçek Zamanlı**: Para ve envanter takibi

## Kurulum

1. Gerekli paketleri yükleyin:
```bash
pip install flask werkzeug
```

2. Uygulamayı çalıştırın:
```bash
python app.py
```

3. Tarayıcınızda `http://localhost:5000` adresine gidin

## Oynanış

1. **Kayıt Olun**: 1000₺ başlangıç parası ve başlangıç ürünleri alın
2. **Ticaret Yapın**: Ürünlerinizi pazarda satın, diğer oyunculardan ürün alın
3. **İş Kolları**: Para biriktirip iş kolları satın alarak pasif gelir elde edin
4. **Seviye Atın**: Ticaret yaparak seviye atlayın ve yeni iş kollarını açın

## Dosya Yapısı

- `app.py` - Ana Flask uygulaması
- `database.py` - Veritabanı bağlantı ve kurulum
- `models.py` - Veri modelleri
- `business_data.py` - İş kolları verileri
- `templates/` - HTML şablonları
- `static/` - CSS ve JavaScript dosyaları

## Geliştirici Notları

- SQLite veritabanı kullanılır (`game.db`)
- Session tabanlı kimlik doğrulama
- Responsive tasarım
- AJAX ile gerçek zamanlı güncellemeler

## Lisans

Bu proje eğitim amaçlı geliştirilmiştir.