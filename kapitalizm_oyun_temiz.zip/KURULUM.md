# Kapitalizm Ticaret Oyunu - Kurulum Rehberi

## Gereksinimler
- Python 3.7 veya üzeri
- pip (Python paket yöneticisi)

## Kurulum Adımları

1. **Projeyi indirin ve klasöre gidin**
```bash
# Zip dosyasını çıkarttıktan sonra
cd kapitalizm_oyun
```

2. **Gerekli paketleri yükleyin**
```bash
pip install flask werkzeug
```

3. **Oyunu başlatın**
```bash
python app.py
```

4. **Oyunu oynayın**
- Tarayıcınızda `http://localhost:5000` adresine gidin
- Kayıt olun (1000₺ başlangıç parası alacaksınız)
- Ticaret yapmaya başlayın!

## Sorun Giderme

**Port zaten kullanımda hatası:**
- app.py dosyasında port numarasını değiştirin (5000 yerine 5001 gibi)

**Veritabanı hatası:**
- game.db dosyasını silin, tekrar çalıştırın

**Paket yükleme hatası:**
```bash
pip install --upgrade pip
pip install flask==3.1.1 werkzeug==3.1.3
```

## Özellikler
- 46 farklı iş kolu
- Gerçek zamanlı ticaret sistemi
- Seviye sistemi
- Responsive tasarım
- Türkçe arayüz

İyi oyunlar!