# Kapitalizm Ticaret Oyunu

## Overview

This is a Flask-based trading game where players can register, manage inventory, buy/sell items in a marketplace, and accumulate wealth. The game features user authentication, inventory management, and a marketplace system with real-time updates.

## System Architecture

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Database**: SQLite3 with raw SQL queries
- **Authentication**: Session-based authentication using Werkzeug password hashing
- **Architecture Pattern**: Traditional MVC with separate models, views (templates), and controllers (routes)

### Frontend Architecture
- **Templates**: Jinja2 templating engine with HTML5
- **Styling**: Custom CSS with responsive design and animations
- **JavaScript**: Vanilla JavaScript for client-side interactions and AJAX calls
- **UI Components**: Custom component system with cards, grids, and forms

### Data Storage
- **Primary Database**: SQLite3 (`game.db`)
- **Schema**: Three main tables (users, items, inventory) with foreign key relationships
- **Data Access**: Custom model classes with static methods for database operations

## Key Components

### User Management
- **Registration**: New users start with 1000₺ and starter items
- **Authentication**: Username/password based login with hashed passwords
- **Session Management**: Flask sessions for maintaining login state

### Inventory System
- **Item Management**: Players can own multiple quantities of various items
- **Item Types**: Base items with descriptions and base prices
- **Inventory Tracking**: User-item relationship with quantity tracking

### Marketplace
- **Trading System**: Players can list items for sale to other players
- **Price Discovery**: Dynamic pricing based on market conditions
- **Real-time Updates**: AJAX-based updates for current market state

### Database Models
- **User Model**: Handles user data, authentication, and money management
- **Item Model**: Manages item definitions and base prices
- **Inventory Model**: Tracks user ownership of items
- **Market Listing Model**: Manages marketplace transactions (planned)

## Data Flow

1. **User Registration**: User creates account → Gets starter money and items → Session created
2. **Login Flow**: Credentials verified → Session established → Redirected to marketplace
3. **Inventory Management**: View items → Select for sale → Set price → List in marketplace
4. **Trading**: Browse marketplace → Purchase items → Update inventories → Transfer money
5. **Real-time Updates**: JavaScript polls server → Updates user stats → Refreshes market data

## External Dependencies

### Python Dependencies
- **Flask 3.1.1**: Web framework and routing
- **Werkzeug 3.1.3**: Password hashing and security utilities
- **Standard Library**: sqlite3, datetime, os for core functionality

### Frontend Dependencies
- **No external JavaScript libraries**: Pure vanilla JS implementation
- **Custom CSS**: No external CSS frameworks, fully custom styling
- **Font**: System fonts (Segoe UI, Tahoma, Geneva, Verdana)

## Deployment Strategy

### Development Environment
- **Replit Configuration**: Python 3.11 environment with Nix package manager
- **Auto-start**: Workflow configured to install dependencies and run Flask app
- **Port Configuration**: Flask runs on port 5000 with automatic port forwarding

### Database Initialization
- **Auto-setup**: Database and tables created automatically on first run
- **Schema Management**: SQL schema defined in `database.py` with IF NOT EXISTS clauses
- **Data Persistence**: SQLite file persists between deployments

### Scaling Considerations
- **Current Setup**: Single-instance SQLite suitable for development
- **Future Migration**: Easy migration path to PostgreSQL with Drizzle ORM
- **Session Storage**: Currently in-memory, can be moved to database for scaling

## Changelog

- June 25, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.