from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
from database import init_db, get_db_connection
from models import User, Item, Inventory, MarketListing

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'your-secret-key-change-this')

# Initialize database
init_db()

@app.route('/')
def index():
    """Ana sayfa - oyun hakkında bilgi ve giriş linkleri"""
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Kullanıcı kayıt işlemi"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        
        if not username or not password or not email:
            flash('Tüm alanlar zorunludur!')
            return render_template('register.html')
        
        conn = get_db_connection()
        
        try:
            # Kullanıcı adı kontrolü
            existing_user = conn.execute(
                'SELECT id FROM users WHERE username = ?', (username,)
            ).fetchone()
            
            if existing_user:
                flash('Bu kullanıcı adı zaten kullanılıyor!')
                return render_template('register.html')
            
            # Yeni kullanıcı oluştur
            password_hash = generate_password_hash(password)
            cursor = conn.execute(
                'INSERT INTO users (username, email, password_hash, money) VALUES (?, ?, ?, ?)',
                (username, email, password_hash, 1000.0)  # Başlangıç parası 1000
            )
            
            # Başlangıç envanteri oluştur
            user_id = cursor.lastrowid
            starting_items = [
                ('Buğday Tohumu', 'Tarım için temel tohum', 10),
                ('Su', 'Temel kaynak', 20),
                ('Basit Alet', 'Üretim için gerekli', 1)
            ]
            
            for item_name, description, quantity in starting_items:
                # Önce item'ı oluştur veya varsa id'sini al
                item = conn.execute(
                    'SELECT id FROM items WHERE name = ?', (item_name,)
                ).fetchone()
                
                if not item:
                    item_cursor = conn.execute(
                        'INSERT INTO items (name, description, base_price) VALUES (?, ?, ?)',
                        (item_name, description, 10.0)
                    )
                    item_id = item_cursor.lastrowid
                else:
                    item_id = item['id']
                
                # Enventere ekle
                conn.execute(
                    'INSERT INTO inventory (user_id, item_id, quantity) VALUES (?, ?, ?)',
                    (user_id, item_id, quantity)
                )
            
            # Kullanıcı seviye kaydı oluştur
            conn.execute(
                'INSERT INTO user_levels (user_id, level, experience) VALUES (?, ?, ?)',
                (user_id, 1, 0)
            )
            
            conn.commit()
            
        except Exception as e:
            conn.rollback()
            flash('Kayıt sırasında hata oluştu! Tekrar deneyin.')
            return render_template('register.html')
        finally:
            conn.close()
        
        flash('Kayıt başarılı! Giriş yapabilirsiniz.')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Kullanıcı giriş işlemi"""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        try:
            user = conn.execute(
                'SELECT * FROM users WHERE username = ?', (username,)
            ).fetchone()
        finally:
            conn.close()
        
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            return redirect(url_for('profile'))
        else:
            flash('Geçersiz kullanıcı adı veya şifre!')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Kullanıcı çıkış işlemi"""
    session.clear()
    return redirect(url_for('index'))

@app.route('/profile')
def profile():
    """Kullanıcı profil sayfası"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    user = conn.execute(
        'SELECT * FROM users WHERE id = ?', (session['user_id'],)
    ).fetchone()
    conn.close()
    
    return render_template('profile.html', user=user)

@app.route('/inventory')
def inventory():
    """Kullanıcı envanter sayfası"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    inventory_items = conn.execute('''
        SELECT i.name, i.description, i.base_price, inv.quantity, inv.id as inventory_id, i.id as item_id
        FROM inventory inv
        JOIN items i ON inv.item_id = i.id
        WHERE inv.user_id = ? AND inv.quantity > 0
        ORDER BY i.name
    ''', (session['user_id'],)).fetchall()
    conn.close()
    
    return render_template('inventory.html', inventory_items=inventory_items)

@app.route('/marketplace')
def marketplace():
    """Pazar alanı - tüm satılık ürünler"""
    conn = get_db_connection()
    
    # Aktif satış ilanlarını getir (kendi ilanları hariç)
    listings = conn.execute('''
        SELECT ml.id, ml.price, ml.quantity, ml.created_at,
               i.name as item_name, i.description as item_description,
               u.username as seller_username
        FROM market_listings ml
        JOIN items i ON ml.item_id = i.id
        JOIN users u ON ml.seller_id = u.id
        WHERE ml.is_active = 1 AND ml.seller_id != ?
        ORDER BY ml.created_at DESC
    ''', (session.get('user_id', 0),)).fetchall()
    
    # Kendi aktif ilanlarını getir
    my_listings = []
    if 'user_id' in session:
        my_listings = conn.execute('''
            SELECT ml.id, ml.price, ml.quantity, ml.created_at,
                   i.name as item_name, i.description as item_description
            FROM market_listings ml
            JOIN items i ON ml.item_id = i.id
            WHERE ml.seller_id = ? AND ml.is_active = 1
            ORDER BY ml.created_at DESC
        ''', (session['user_id'],)).fetchall()
    
    conn.close()
    
    return render_template('marketplace.html', listings=listings, my_listings=my_listings)

@app.route('/sell_item/<int:inventory_id>')
def sell_item_form(inventory_id):
    """Ürün satış formu"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    item = conn.execute('''
        SELECT i.name, i.description, i.base_price, inv.quantity, inv.id as inventory_id
        FROM inventory inv
        JOIN items i ON inv.item_id = i.id
        WHERE inv.id = ? AND inv.user_id = ?
    ''', (inventory_id, session['user_id'])).fetchone()
    conn.close()
    
    if not item:
        flash('Ürün bulunamadı!')
        return redirect(url_for('inventory'))
    
    return render_template('sell_item.html', item=item)

@app.route('/list_item', methods=['POST'])
def list_item():
    """Ürünü pazara sunma işlemi"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    inventory_id = request.form['inventory_id']
    price = float(request.form['price'])
    quantity = int(request.form['quantity'])
    
    if price <= 0 or quantity <= 0:
        flash('Fiyat ve miktar pozitif olmalıdır!')
        return redirect(url_for('inventory'))
    
    conn = get_db_connection()
    
    # Envanter kontrolü
    inventory_item = conn.execute('''
        SELECT inv.quantity, inv.item_id, i.name
        FROM inventory inv
        JOIN items i ON inv.item_id = i.id
        WHERE inv.id = ? AND inv.user_id = ?
    ''', (inventory_id, session['user_id'])).fetchone()
    
    if not inventory_item or inventory_item['quantity'] < quantity:
        flash('Yeterli ürün yok!')
        conn.close()
        return redirect(url_for('inventory'))
    
    # Pazara ekle
    conn.execute('''
        INSERT INTO market_listings (seller_id, item_id, quantity, price, created_at, is_active)
        VALUES (?, ?, ?, ?, ?, 1)
    ''', (session['user_id'], inventory_item['item_id'], quantity, price, datetime.now()))
    
    # Envanterden düş
    new_quantity = inventory_item['quantity'] - quantity
    if new_quantity == 0:
        conn.execute('DELETE FROM inventory WHERE id = ?', (inventory_id,))
    else:
        conn.execute('UPDATE inventory SET quantity = ? WHERE id = ?', (new_quantity, inventory_id))
    
    conn.commit()
    conn.close()
    
    flash(f'{quantity} adet {inventory_item["name"]} pazara sunuldu!')
    return redirect(url_for('marketplace'))

@app.route('/buy_item/<int:listing_id>')
def buy_item(listing_id):
    """Pazardan ürün satın alma"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    
    # İlan detaylarını getir
    listing = conn.execute('''
        SELECT ml.*, i.name as item_name, u.username as seller_username
        FROM market_listings ml
        JOIN items i ON ml.item_id = i.id
        JOIN users u ON ml.seller_id = u.id
        WHERE ml.id = ? AND ml.is_active = 1
    ''', (listing_id,)).fetchone()
    
    if not listing:
        flash('İlan bulunamadı veya artık aktif değil!')
        conn.close()
        return redirect(url_for('marketplace'))
    
    if listing['seller_id'] == session['user_id']:
        flash('Kendi ürününüzü satın alamazsınız!')
        conn.close()
        return redirect(url_for('marketplace'))
    
    # Alıcının parasını kontrol et
    buyer = conn.execute('SELECT money FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    total_cost = listing['price'] * listing['quantity']
    
    if buyer['money'] < total_cost:
        flash('Yeterli paranız yok!')
        conn.close()
        return redirect(url_for('marketplace'))
    
    # İşlemi gerçekleştir
    try:
        # Para transferi
        conn.execute('UPDATE users SET money = money - ? WHERE id = ?', (total_cost, session['user_id']))
        conn.execute('UPDATE users SET money = money + ? WHERE id = ?', (total_cost, listing['seller_id']))
        
        # Ürünü alıcının envanterine ekle
        existing_inventory = conn.execute('''
            SELECT id, quantity FROM inventory 
            WHERE user_id = ? AND item_id = ?
        ''', (session['user_id'], listing['item_id'])).fetchone()
        
        if existing_inventory:
            conn.execute('''
                UPDATE inventory SET quantity = quantity + ? 
                WHERE id = ?
            ''', (listing['quantity'], existing_inventory['id']))
        else:
            conn.execute('''
                INSERT INTO inventory (user_id, item_id, quantity)
                VALUES (?, ?, ?)
            ''', (session['user_id'], listing['item_id'], listing['quantity']))
        
        # İlanı pasif yap
        conn.execute('UPDATE market_listings SET is_active = 0 WHERE id = ?', (listing_id,))
        
        conn.commit()
        flash(f'{listing["quantity"]} adet {listing["item_name"]} başarıyla satın alındı!')
        
    except Exception as e:
        conn.rollback()
        flash('Satın alma işlemi başarısız!')
    
    conn.close()
    return redirect(url_for('marketplace'))

@app.route('/cancel_listing/<int:listing_id>')
def cancel_listing(listing_id):
    """Satış ilanını iptal etme"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    
    # İlan kontrolü
    listing = conn.execute('''
        SELECT * FROM market_listings 
        WHERE id = ? AND seller_id = ? AND is_active = 1
    ''', (listing_id, session['user_id'])).fetchone()
    
    if not listing:
        flash('İlan bulunamadı!')
        conn.close()
        return redirect(url_for('marketplace'))
    
    # Ürünü enventere geri ekle
    existing_inventory = conn.execute('''
        SELECT id, quantity FROM inventory 
        WHERE user_id = ? AND item_id = ?
    ''', (session['user_id'], listing['item_id'])).fetchone()
    
    if existing_inventory:
        conn.execute('''
            UPDATE inventory SET quantity = quantity + ? 
            WHERE id = ?
        ''', (listing['quantity'], existing_inventory['id']))
    else:
        conn.execute('''
            INSERT INTO inventory (user_id, item_id, quantity)
            VALUES (?, ?, ?)
        ''', (session['user_id'], listing['item_id'], listing['quantity']))
    
    # İlanı iptal et
    conn.execute('UPDATE market_listings SET is_active = 0 WHERE id = ?', (listing_id,))
    
    conn.commit()
    conn.close()
    
    flash('İlan iptal edildi ve ürün envanterinize geri eklendi!')
    return redirect(url_for('marketplace'))

@app.route('/businesses')
def businesses():
    """İş kolları sayfası"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    try:
        # Kullanıcı seviyesi
        user_level = conn.execute('''
            SELECT level FROM user_levels WHERE user_id = ?
        ''', (session['user_id'],)).fetchone()
        
        current_level = user_level['level'] if user_level else 1
        
        # Tüm iş kolları
        all_businesses = conn.execute('''
            SELECT b.*, ub.quantity as owned_quantity
            FROM businesses b
            LEFT JOIN user_businesses ub ON b.id = ub.business_id AND ub.user_id = ?
            ORDER BY b.category, b.required_level
        ''', (session['user_id'],)).fetchall()
        
        # Kullanıcının parasını al
        user = conn.execute('SELECT money FROM users WHERE id = ?', (session['user_id'],)).fetchone()
        
        # Kategorilere ayır
        businesses_by_category = {
            'shop': [],
            'mine': [],
            'farm': [],
            'factory': [],
            'service': []
        }
        
        for business in all_businesses:
            businesses_by_category[business['category']].append(business)
            
    finally:
        conn.close()
    
    return render_template('businesses.html', 
                         businesses_by_category=businesses_by_category,
                         current_level=current_level,
                         user_money=user['money'])

@app.route('/buy_business/<int:business_id>')
def buy_business(business_id):
    """İş kolu satın alma"""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    conn = get_db_connection()
    try:
        # İş kolu bilgilerini al
        business = conn.execute('''
            SELECT * FROM businesses WHERE id = ?
        ''', (business_id,)).fetchone()
        
        if not business:
            flash('İş kolu bulunamadı!')
            return redirect(url_for('businesses'))
        
        # Kullanıcı bilgilerini al
        user = conn.execute('SELECT money FROM users WHERE id = ?', (session['user_id'],)).fetchone()
        user_level = conn.execute('SELECT level FROM user_levels WHERE user_id = ?', (session['user_id'],)).fetchone()
        
        current_level = user_level['level'] if user_level else 1
        
        # Seviye kontrolü
        if current_level < business['required_level']:
            flash(f'Bu iş kolu için {business["required_level"]} seviye gerekli!')
            return redirect(url_for('businesses'))
        
        # Para kontrolü
        if user['money'] < business['price']:
            flash('Yeterli paranız yok!')
            return redirect(url_for('businesses'))
        
        # Zaten sahip mi kontrolü
        existing = conn.execute('''
            SELECT quantity FROM user_businesses 
            WHERE user_id = ? AND business_id = ?
        ''', (session['user_id'], business_id)).fetchone()
        
        if existing:
            # Miktarı artır
            conn.execute('''
                UPDATE user_businesses SET quantity = quantity + 1 
                WHERE user_id = ? AND business_id = ?
            ''', (session['user_id'], business_id))
        else:
            # Yeni iş kolu ekle
            conn.execute('''
                INSERT INTO user_businesses (user_id, business_id, quantity)
                VALUES (?, ?, 1)
            ''', (session['user_id'], business_id))
        
        # Parayı düş
        conn.execute('''
            UPDATE users SET money = money - ? WHERE id = ?
        ''', (business['price'], session['user_id']))
        
        conn.commit()
        flash(f'{business["name"]} başarıyla satın alındı!')
        
    except Exception as e:
        conn.rollback()
        flash('Satın alma işlemi başarısız!')
    finally:
        conn.close()
    
    return redirect(url_for('businesses'))

@app.route('/api/user_stats')
def api_user_stats():
    """Kullanıcı istatistikleri API"""
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    conn = get_db_connection()
    try:
        # Kullanıcı bilgileri
        user = conn.execute('SELECT money FROM users WHERE id = ?', (session['user_id'],)).fetchone()
        
        # Envanter sayısı
        inventory_count = conn.execute('''
            SELECT COUNT(*) as count FROM inventory 
            WHERE user_id = ? AND quantity > 0
        ''', (session['user_id'],)).fetchone()
        
        # Aktif ilan sayısı
        active_listings = conn.execute('''
            SELECT COUNT(*) as count FROM market_listings 
            WHERE seller_id = ? AND is_active = 1
        ''', (session['user_id'],)).fetchone()
        
        # İş kolu sayısı
        business_count = conn.execute('''
            SELECT COALESCE(SUM(quantity), 0) as count FROM user_businesses 
            WHERE user_id = ?
        ''', (session['user_id'],)).fetchone()
        
    finally:
        conn.close()
    
    return jsonify({
        'money': user['money'],
        'inventory_items': inventory_count['count'],
        'active_listings': active_listings['count'],
        'businesses': business_count['count']
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
