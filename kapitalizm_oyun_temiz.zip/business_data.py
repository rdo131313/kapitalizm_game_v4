# İş kolları veri yapısı - GitHub kodlarından ilham alınarak
BUSINESS_TYPES = {
    'shops': {
        'name': 'Dükkânlar',
        'icon': '🏪',
        'businesses': [
            {'id': 1, 'name': 'Bakkal Dükkânı', 'price': 1000, 'daily_income': 150, 'required_level': 1},
            {'id': 2, 'name': 'Teknoloji Mağazası', 'price': 5000, 'daily_income': 800, 'required_level': 5},
            {'id': 3, 'name': 'Gıda Marketi', 'price': 8000, 'daily_income': 1200, 'required_level': 8},
            {'id': 4, 'name': 'Giyim Mağazası', 'price': 12000, 'daily_income': 1800, 'required_level': 12},
            {'id': 5, 'name': 'Elektronik Mağazası', 'price': 20000, 'daily_income': 3000, 'required_level': 15},
            {'id': 6, 'name': 'Mobilya Mağazası', 'price': 35000, 'daily_income': 5000, 'required_level': 20},
            {'id': 7, 'name': 'Otomobil Galerisi', 'price': 60000, 'daily_income': 8500, 'required_level': 25},
            {'id': 8, 'name': 'Lüks Butik', 'price': 100000, 'daily_income': 15000, 'required_level': 30},
            {'id': 9, 'name': 'Alışveriş Merkezi', 'price': 200000, 'daily_income': 30000, 'required_level': 40},
            {'id': 10, 'name': 'Süpermarket Zinciri', 'price': 500000, 'daily_income': 75000, 'required_level': 50}
        ]
    },
    'mines': {
        'name': 'Madenler',
        'icon': '⛏️',
        'businesses': [
            {'id': 11, 'name': 'Kum Ocağı', 'price': 3000, 'daily_income': 400, 'required_level': 3},
            {'id': 12, 'name': 'Kömür Madeni', 'price': 10000, 'daily_income': 1500, 'required_level': 7},
            {'id': 13, 'name': 'Demir Madeni', 'price': 25000, 'daily_income': 3500, 'required_level': 12},
            {'id': 14, 'name': 'Bakır Madeni', 'price': 40000, 'daily_income': 5500, 'required_level': 16},
            {'id': 15, 'name': 'Gümüş Madeni', 'price': 75000, 'daily_income': 10000, 'required_level': 22},
            {'id': 16, 'name': 'Altın Madeni', 'price': 150000, 'daily_income': 20000, 'required_level': 28},
            {'id': 17, 'name': 'Platin Madeni', 'price': 300000, 'daily_income': 40000, 'required_level': 35},
            {'id': 18, 'name': 'Elmas Madeni', 'price': 600000, 'daily_income': 80000, 'required_level': 42},
            {'id': 19, 'name': 'Nadir Toprak Madeni', 'price': 1000000, 'daily_income': 130000, 'required_level': 48},
            {'id': 20, 'name': 'Uranyum Madeni', 'price': 2000000, 'daily_income': 250000, 'required_level': 55}
        ]
    },
    'farms': {
        'name': 'Araziler',
        'icon': '🌾',
        'businesses': [
            {'id': 21, 'name': 'Sebze Bahçesi', 'price': 2000, 'daily_income': 300, 'required_level': 2},
            {'id': 22, 'name': 'Buğday Tarlası', 'price': 5000, 'daily_income': 700, 'required_level': 4},
            {'id': 23, 'name': 'Meyve Bahçesi', 'price': 8000, 'daily_income': 1100, 'required_level': 6},
            {'id': 24, 'name': 'Hayvancılık Çiftliği', 'price': 15000, 'daily_income': 2200, 'required_level': 10},
            {'id': 25, 'name': 'Bal Üretim Çiftliği', 'price': 25000, 'daily_income': 3500, 'required_level': 14},
            {'id': 26, 'name': 'Organik Tarım', 'price': 45000, 'daily_income': 6500, 'required_level': 18},
            {'id': 27, 'name': 'Seracılık', 'price': 80000, 'daily_income': 11000, 'required_level': 24},
            {'id': 28, 'name': 'Büyük Çiftlik', 'price': 150000, 'daily_income': 20000, 'required_level': 30},
            {'id': 29, 'name': 'Tarım Kooperatifi', 'price': 300000, 'daily_income': 40000, 'required_level': 38},
            {'id': 30, 'name': 'Tarımsal Holding', 'price': 600000, 'daily_income': 80000, 'required_level': 45}
        ]
    },
    'factories': {
        'name': 'Fabrikalar',
        'icon': '🏭',
        'businesses': [
            {'id': 31, 'name': 'Küçük Atölye', 'price': 7000, 'daily_income': 1000, 'required_level': 6},
            {'id': 32, 'name': 'Tekstil Fabrikası', 'price': 20000, 'daily_income': 2800, 'required_level': 11},
            {'id': 33, 'name': 'Gıda İşleme Fabrikası', 'price': 40000, 'daily_income': 5500, 'required_level': 16},
            {'id': 34, 'name': 'Mobilya Fabrikası', 'price': 70000, 'daily_income': 9500, 'required_level': 21},
            {'id': 35, 'name': 'Elektronik Fabrikası', 'price': 120000, 'daily_income': 16000, 'required_level': 26},
            {'id': 36, 'name': 'Otomobil Fabrikası', 'price': 250000, 'daily_income': 32000, 'required_level': 32},
            {'id': 37, 'name': 'Kimya Fabrikası', 'price': 400000, 'daily_income': 55000, 'required_level': 38},
            {'id': 38, 'name': 'Çelik Fabrikası', 'price': 700000, 'daily_income': 95000, 'required_level': 44},
            {'id': 39, 'name': 'Havacılık Fabrikası', 'price': 1200000, 'daily_income': 160000, 'required_level': 50},
            {'id': 40, 'name': 'Teknoloji Üssü', 'price': 2500000, 'daily_income': 320000, 'required_level': 60}
        ]
    },
    'services': {
        'name': 'Hizmet Sektörü',
        'icon': '🏢',
        'businesses': [
            {'id': 41, 'name': 'Berber Salonu', 'price': 3000, 'daily_income': 450, 'required_level': 3},
            {'id': 42, 'name': 'Restoran', 'price': 12000, 'daily_income': 1700, 'required_level': 9},
            {'id': 43, 'name': 'Otel', 'price': 50000, 'daily_income': 7000, 'required_level': 19},
            {'id': 44, 'name': 'Hastane', 'price': 200000, 'daily_income': 25000, 'required_level': 33},
            {'id': 45, 'name': 'Üniversite', 'price': 800000, 'daily_income': 100000, 'required_level': 47},
            {'id': 46, 'name': 'Medya Grubu', 'price': 1500000, 'daily_income': 180000, 'required_level': 55}
        ]
    }
}

def get_business_by_id(business_id):
    """ID ile iş kolu bilgisi getir"""
    for category in BUSINESS_TYPES.values():
        for business in category['businesses']:
            if business['id'] == business_id:
                return business
    return None

def get_businesses_by_category(category):
    """Kategoriye göre iş kolları getir"""
    return BUSINESS_TYPES.get(category, {}).get('businesses', [])

def get_all_businesses():
    """Tüm iş kollarını getir"""
    all_businesses = []
    for category in BUSINESS_TYPES.values():
        all_businesses.extend(category['businesses'])
    return all_businesses