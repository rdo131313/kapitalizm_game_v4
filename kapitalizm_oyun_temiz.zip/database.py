import sqlite3
import os

DATABASE_PATH = 'game.db'

def get_db_connection():
    """Veritabanı bağlantısı oluştur"""
    conn = sqlite3.connect(DATABASE_PATH, timeout=30.0, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=DELETE')
    conn.execute('PRAGMA synchronous=FULL')
    conn.execute('PRAGMA locking_mode=NORMAL')
    conn.execute('PRAGMA temp_store=MEMORY')
    return conn

def init_db():
    """Veritabanını başlat ve tabloları oluştur"""
    conn = get_db_connection()
    
    # Kullanıcılar tablosu
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            money REAL DEFAULT 1000.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Ürünler tablosu
    conn.execute('''
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT,
            base_price REAL DEFAULT 10.0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Envanter tablosu
    conn.execute('''
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            quantity INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (item_id) REFERENCES items (id),
            UNIQUE(user_id, item_id)
        )
    ''')
    
    # Pazar ilanları tablosu
    conn.execute('''
        CREATE TABLE IF NOT EXISTS market_listings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (seller_id) REFERENCES users (id),
            FOREIGN KEY (item_id) REFERENCES items (id)
        )
    ''')
    
    # İşlem geçmişi tablosu (opsiyonel - gelecek özellikler için)
    conn.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            buyer_id INTEGER NOT NULL,
            seller_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL,
            total_amount REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (buyer_id) REFERENCES users (id),
            FOREIGN KEY (seller_id) REFERENCES users (id),
            FOREIGN KEY (item_id) REFERENCES items (id)
        )
    ''')
    
    # İş kolları tablosu
    conn.execute('''
        CREATE TABLE IF NOT EXISTS businesses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            price REAL NOT NULL,
            daily_income REAL NOT NULL,
            required_level INTEGER DEFAULT 1,
            description TEXT,
            icon TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Kullanıcı iş kolları tablosu
    conn.execute('''
        CREATE TABLE IF NOT EXISTS user_businesses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            business_id INTEGER NOT NULL,
            quantity INTEGER DEFAULT 1,
            purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_collection TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (business_id) REFERENCES businesses (id),
            UNIQUE(user_id, business_id)
        )
    ''')
    
    # Kullanıcı seviye tablosu
    conn.execute('''
        CREATE TABLE IF NOT EXISTS user_levels (
            user_id INTEGER PRIMARY KEY,
            level INTEGER DEFAULT 1,
            experience INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    conn.commit()
    
    # İş kolları verilerini ekle
    init_business_data(conn)
    
    conn.close()
    print("Veritabanı başlatıldı!")

def init_business_data(conn):
    """İş kolları verilerini veritabanına ekle"""
    from business_data import get_all_businesses
    
    # Mevcut iş kolları sayısını kontrol et
    existing_count = conn.execute('SELECT COUNT(*) as count FROM businesses').fetchone()['count']
    
    if existing_count == 0:
        businesses = get_all_businesses()
        for business in businesses:
            conn.execute('''
                INSERT INTO businesses (id, name, category, price, daily_income, required_level, description, icon)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                business['id'],
                business['name'],
                'shop' if business['id'] <= 10 else 'mine' if business['id'] <= 20 else 'farm' if business['id'] <= 30 else 'factory' if business['id'] <= 40 else 'service',
                business['price'],
                business['daily_income'],
                business['required_level'],
                f"{business['name']} - Günlük {business['daily_income']} TL gelir sağlar",
                '🏪' if business['id'] <= 10 else '⛏️' if business['id'] <= 20 else '🌾' if business['id'] <= 30 else '🏭' if business['id'] <= 40 else '🏢'
            ))
        conn.commit()
        print(f"{len(businesses)} iş kolu veritabanına eklendi!")

if __name__ == '__main__':
    init_db()
